<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CURA_TestSuite_MakeAppointment_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>221910301050@gitam.in;</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>37d68bef-d6c9-462a-a62c-ebd4321cc230</testSuiteGuid>
   <testCaseLink>
      <guid>c7bc3169-7700-4f50-924a-cc341405bb84</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_CURA_MakeAppointment_002</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>88c76fac-49f5-424a-bca4-5fd1da8784b5</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_Test Data/CURA_Login_TestData</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
